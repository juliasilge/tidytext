# kdtools 0.3.1

* Additional bug fixes

# kdtools 0.3.0

* Bug fix in lower/upper_bound

# kdtools 0.2.0

* For upload to CRAN

# kdtools 0.1.1

* Added a `NEWS.md` file to track changes to the package.
* Fixed a bug in vignette building
