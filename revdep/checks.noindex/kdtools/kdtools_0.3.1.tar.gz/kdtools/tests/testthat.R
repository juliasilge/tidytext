library(testthat)
library(kdtools)

test_check("kdtools")
