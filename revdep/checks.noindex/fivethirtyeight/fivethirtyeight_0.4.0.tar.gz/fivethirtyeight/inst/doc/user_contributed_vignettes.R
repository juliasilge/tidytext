## ----install, eval=FALSE-------------------------------------------------
#  # install.packages("remotes")
#  remotes::install_github("rudeboybert/fivethirtyeight", build_vignettes = TRUE)

