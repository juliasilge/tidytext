## textmineR-deprecated.r
#' @title Deprecated functions in package \pkg{textmineR}.
#' @description The functions listed below are deprecated and will be defunct in
#'   the near future. When possible, alternative functions with similar
#'   functionality are also mentioned.
#' @name textmineR-deprecated
#' @keywords internal
#' @details 
#' Below is a list of deprecated functions:
#' RecursiveRbind
#' Vec2Dtm
#' JSD
#' HellDist
#' GetPhiPrime
#' FormatRawLdaOutput
#' Files2Vec
#' DepluralizeDtm
#' CorrectS
#' CalcPhiPrime
NULL