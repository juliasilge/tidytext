library(testthat)
library(textmineR)

test_check("textmineR")