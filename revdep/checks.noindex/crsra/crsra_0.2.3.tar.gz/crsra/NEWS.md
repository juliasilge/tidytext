# crsra 0.2.0

* Added a `NEWS.md` file to track changes to the package.

* First submission to CRAN.

# crsra 0.2.1

* Added a vignette for how to do simple analysis with the package

# crsra 0.2.2

* Updated the DESCRIPTION file with more information about Coursera Inc. and 
the potential use for the package

# crsra 0.2.3

* Corrected the link in the DESCRIPTION file.
