library(testthat)
library(crsra)

test_check("crsra")
