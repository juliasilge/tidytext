library(testthat)
library(fedregs)

test_check("fedregs")
