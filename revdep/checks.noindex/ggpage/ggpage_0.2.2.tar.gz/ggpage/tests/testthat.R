library(testthat)
library(ggpage)

test_check("ggpage")
