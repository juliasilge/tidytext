# ggpage 0.2.2

* Added a `NEWS.md` file to track changes to the package.
