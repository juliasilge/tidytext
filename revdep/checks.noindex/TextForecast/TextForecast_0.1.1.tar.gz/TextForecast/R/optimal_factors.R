#' @title Optimal Factors
#'
#' @description A simple vector containing the Optimal factors  select by optimal_number_factors function.
#'
#' @format A vector with 1 component.
#'
#' \describe{
#' \item{optimal fators x}{The vector of factor.}
#' }
"optimal_factors"
