library(testthat)
library(LexisNexisTools)

test_check("LexisNexisTools")
