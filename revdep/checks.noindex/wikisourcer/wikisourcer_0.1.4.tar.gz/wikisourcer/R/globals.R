globalVariables(c(".", "wikisource_book", "wikisource_page", "language", "page", "text", "title"))
