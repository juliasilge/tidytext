# wikisourcer 0.1.3

* Added a `NEWS.md` file to track changes to the package.
* Fixed and improved vignette.
* Removed `dplyr` and `stringr`dependencies.
* Added the boolean `cleaned` variables to give the possibility to download all the metadata of the wikipages.

# wikisourcer 0.1.4

* Fixed vignette links.
