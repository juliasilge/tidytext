library(testthat)
library(available)

test_check("available")
