#' Terms Country
#' 
#' This dataframe provides possible countries you want to get 
#' news from. This dataframe is relevant in conjunction with 
#' \code{get_headlines}.
#' 
"terms_country"