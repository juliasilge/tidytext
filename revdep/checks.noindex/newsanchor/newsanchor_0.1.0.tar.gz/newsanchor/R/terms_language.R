#' Terms Language
#' 
#' This dataframe provides possible languages you want to get 
#' news for. This dataframe is relevant in conjunction with
#'  \code{get_everything}.
#' 
"terms_language"