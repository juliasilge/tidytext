#' Terms Category
#' 
#' The dataframe `provides possible categories (e.g., sports) you want to get 
#' headlines for. This dataframe is relevant in conjunction with 
#' \code{get_headlines}.
"terms_category"

