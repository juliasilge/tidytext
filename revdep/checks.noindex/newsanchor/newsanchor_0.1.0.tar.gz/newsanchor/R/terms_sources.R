#' Terms Sources
#'
#'This dataframe provides possible news sources or blogs you want
#'to get news from. This dataframe is relevant in conjunction with 
#'\code{get_everything}.
"terms_sources"