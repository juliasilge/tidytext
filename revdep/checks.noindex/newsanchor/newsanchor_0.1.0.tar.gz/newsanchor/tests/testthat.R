library(testthat)
library(newsanchor)

test_check("newsanchor")
