library(testthat)
library(saotd)

test_check("saotd")
