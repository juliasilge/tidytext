#' @importFrom magrittr %>% 
#' @export
magrittr::`%>%`