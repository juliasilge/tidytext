library(testthat)
library(tidymodels)

test_check("tidymodels")
