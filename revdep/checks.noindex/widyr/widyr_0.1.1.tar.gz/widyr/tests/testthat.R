library(testthat)
library(widyr)

test_check("widyr")
