# tests for pairwise_count function

context("pairwise_pmi")

suppressPackageStartupMessages(library(dplyr))
suppressPackageStartupMessages(library(tidytext))
