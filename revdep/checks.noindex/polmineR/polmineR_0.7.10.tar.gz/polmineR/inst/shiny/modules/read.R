#' @rdname shiny_helper_functions
#' @export readUiInput
readUiInput <- function(){}


#' @rdname shiny_helper_functions
#' @export readUiOutput
readUiOutput <- function() uiOutput("read_fulltext")


#' @rdname shiny_helper_functions
#' @export readServer
readServer <- function(input, output, session){
  
}